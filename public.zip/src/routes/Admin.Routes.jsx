import Dashboard from "../Admin/pages/dashboard/Dashboard"

const AdminRoutes=[
    {name:"Admin Dashboard",path:"",element:<Dashboard/>,isPrivate:false},
 ]

export default AdminRoutes