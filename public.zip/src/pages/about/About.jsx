import React from 'react'
import "./style.css"

function About() {
  return (
    <div>index</div>
  )
}
export default About